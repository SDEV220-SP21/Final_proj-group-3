
# Because I was having trouble getting the Code to work, I wrote this program
#simply to have a template for drawing the house in canvas. You just check the
#radiobuttons 1 through 7 and it will draw the house
import Christian_Drake
import wordChoice
from tkinter import *
Christian_Drake.miss_Count = 0
global count
count = 0
wordChoice.fileOpen()
wordChoice.getword()
class HangmanGUI:

    
    def __init__(self):
        global LG2
        global count
        count = 0
        window = Tk()
        window.title("Hangman 2: House Edition")
        self.width = 1000
        self.height = 500

        frame2 = Frame(window)
        frame2.pack()
        self.canvas = Canvas(frame2, width=self.width, height=self.height, bg='white')
        self.canvas.pack()
        
        frame1 = Frame(window)
        frame1.pack()
        def gameOver(self):
            self.canvas.delete('house')
            self.canvas.create_text(500,450,fill="darkblue",font="Times 20 italic bold", text="input continue then press new game, to continue", tags = "house")
           
        def gameRun(name):
            
            global LG2
            global count
            global hW2
            if count == 4:
                gameOver(self)
            letterGuess =  name_Tf.get()
            if letterGuess == "continue":
                Christian_Drake.miss_Count = -1
                count = 0
                wordChoice.fileOpen()
                wordChoice.getword()
            LG2 = letterGuess
            
            if count == 0:
                Christian_Drake.playerInput(0, wordChoice.hidden_Word, wordChoice.chosen_Word, letterGuess)
                count = 1
            else:
                if Christian_Drake.miss_Count < 7:
                    Christian_Drake.playerInput(Christian_Drake.miss_Count, Christian_Drake.hidden_Word2, wordChoice.chosen_Word, letterGuess)
                else:
                    count = 4
            hW2 = Christian_Drake.hidden_Word2
        Label(frame2, text = "Guess A Letter: ").pack(side = LEFT)
#letterGuess = StringVar()
        
        name_Tf = Entry(window)
        name_Tf.bind('<Return>', gameRun)
        
        name_Tf.pack(side = LEFT)
        LG2 = name_Tf.get()
        #Button(frame2, text = "Guess", command = gameRun).pack(side = LEFT)
        Button(frame2, text = "Load screen", command = self.processButtons).pack(side = LEFT)
        Button(frame2, text = "new game", command = self.newGame).pack(side = LEFT)
        
    
        
     #   self.guesses = IntVar()
        
        
    #    rbgus1 = Radiobutton(frame1, text = "Guess 1",
   #                             variable = self.guesses, value =1,
  #                              command = self.processButtons)
 #       rbgus2 = Radiobutton(frame1, text = "Guess 2",
#       #                         variable = self.guesses, value =2,
      #                          command = self.processButtons)
     #   rbgus3 = Radiobutton(frame1, text = "Guess 3",
    #                            variable = self.guesses, value =3,
   #                             command = self.processButtons)
  #      rbgus4 = Radiobutton(frame1, text = "Guess 4",
      #                          variable = self.guesses, value =4,
     #                           command = self.processButtons)
    #    rbgus5 = Radiobutton(frame1, text = "Guess 5",
         #                       variable = self.guesses, value =5,
        #                        command = self.processButtons)
       # rbgus6 = Radiobutton(frame1, text = "Guess 6",
      #                          variable = self.guesses, value =6,
  #                              command = self.processButtons)
   #     rbgus7 = Radiobutton(frame1, text = "Guess 7",
    #                            variable = self.guesses, value =7,
     #                           command = self.processButtons)
 #       
#        
        
  #      rbgus1.grid(row = 1, column = 1)
 #       rbgus2.grid(row = 1, column = 2)
#        rbgus3.grid(row = 1, column = 3)
       # rbgus4.grid(row = 1, column = 4)
        # rbgus5.grid(row = 1, column = 5)
       # rbgus6.grid(row = 1, column = 6)
      #  rbgus7.grid(row = 1, column = 7)
        
        window.mainloop()

    #def processButtons(self):
        
        #color = 'grey'
        #self.clear()
    def newGame(self):
        Christian_Drake.miss_Count = 0
        global count
        count = 0
        wordChoice.fileOpen()
        wordChoice.getword()

    def processButtons(self):
       global LG2
       global hW2
       global count
      
       self.canvas.delete("house")
       self.canvas.create_text(500,450,fill="darkblue",font="Times 20 italic bold", text=hW2, tags = "house")
       #self.canvas.create_text(100,10,fill="darkblue",font="Times 20 italic bold", text=Christian_Drake.hidden_Word2, tags = "house")
       numWrong = Christian_Drake.miss_Count
       
            
       if numWrong >= 1:
            self.canvas.create_line(250, 400, 750, 400 , tags = "house")
       if numWrong >= 2:
            self.canvas.create_line(250, 400, 250, 225 , tags = "house")
       if numWrong >= 3:
            self.canvas.create_line(750, 225, 750, 400 , tags = "house")
       if numWrong >= 4:
            self.canvas.create_line(150, 225, 850, 225 , tags = "house")
       if numWrong >= 5:
            self.canvas.create_line(150, 225, 500, 20 , tags = "house")
       if numWrong >= 6:
            self.canvas.create_line(500, 20, 850, 225 , tags = "house")
       if numWrong >= 7:
            self.canvas.create_rectangle(450, 400, 550, 250 , tags = "house")
            self.canvas.create_oval(520, 330, 535, 345, tags = "house")
            self.canvas.create_rectangle(290, 330, 375, 250, tags = "house")
            self.canvas.create_rectangle(710, 330, 625, 250, tags = "house")
            self.canvas.create_line(332, 330, 332, 250 , tags = "house")
            self.canvas.create_line(290, 290, 375, 290 , tags = "house")
            self.canvas.create_line(667, 330, 667, 250 , tags = "house")
            self.canvas.create_line(625, 290, 710, 290 , tags = "house") 

    
        
                                    
        
            
        
        #print("you have " + ("Diamond " if self.radio == 1 else "Triangle"))

     


        



HangmanGUI()

